from __future__ import annotations

import json


def build_analysis_prompt(file_path: str, language: str, start_line: int, end_line: int, code: str) -> str:
    schema = {
        "issues": [
            {
                "type": "bug/security/performance/code_smell",
                "severity": "low/medium/high",
                "description": "string",
                "line": 0,
                "fix": "string",
            }
        ],
        "quality_score": 0,
        "summary": "string",
    }
    return (
        "You are a senior software engineer. Analyze the following code and identify:\n"
        "- Bugs\n- Security issues\n- Performance problems\n- Code smells\n\n"
        "Return strictly valid JSON only, no markdown.\n"
        f"Expected JSON schema example:\n{json.dumps(schema)}\n\n"
        f"Context: file={file_path}, language={language}, lines={start_line}-{end_line}\n"
        "Code:\n"
        f"```{language}\n"
        f"{code}\n"
        "```"
    )
