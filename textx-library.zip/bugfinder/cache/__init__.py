"""Caching utilities."""
