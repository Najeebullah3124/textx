from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class AnalysisIssue:
    issue_type: str
    severity: str
    description: str
    file_path: str
    line: int | None = None
    fix: str | None = None
    source: str = "static"
    confidence: float | None = None

    def key(self) -> tuple[Any, ...]:
        return (
            self.issue_type.strip().lower(),
            self.severity.strip().lower(),
            self.description.strip().lower(),
            self.file_path,
            self.line,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.issue_type,
            "severity": self.severity,
            "description": self.description,
            "file": self.file_path,
            "line": self.line,
            "fix": self.fix,
            "source": self.source,
            "confidence": self.confidence,
        }


@dataclass(slots=True)
class AnalysisReport:
    root_path: str
    issues: list[AnalysisIssue] = field(default_factory=list)
    files_scanned: int = 0
    chunks_analyzed: int = 0
    ai_provider: str = "none"
    ai_model: str | None = None
    estimated_cost_usd: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "root_path": self.root_path,
            "files_scanned": self.files_scanned,
            "chunks_analyzed": self.chunks_analyzed,
            "ai_provider": self.ai_provider,
            "ai_model": self.ai_model,
            "estimated_cost_usd": round(self.estimated_cost_usd, 6),
            "issues": [issue.to_dict() for issue in self.issues],
        }
